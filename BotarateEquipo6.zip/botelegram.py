from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import requests
import re
import random


def start(update, context):
    global salir
    salir = True
    if salir:
        update.message.reply_text("Oído cocina. Tú dirás...")
        salir = False


def help(update, context):
    if not salir:
        update.message.reply_text('help command received')


def error(update, context):
    if not salir:
        update.message.reply_text('an error occured')


def final(update, context):
    global salir

    if not salir:
        update.message.reply_text('Hasta la próxima')
        salir = True


def funcita(update, context):
    if not salir:
        cita = ['Al no ser los únicos, decidimos ser los mejores. (Gorka Lomeña)',
                'Si la depuración es el proceso de eliminar errores, entonces la programación debe ser el proceso de introducirlos. (Edsger Dijkstra)',
                'Pensar es el trabajo más difícil que existe. Quizá esa sea la razón por la que haya tan pocas personas que lo practiquen. (Henry Ford)',
                'No es que sea muy inteligente. Es simplemente que estoy más tiempo con los problemas. (Albert Einstein)',
                'Programar no es un talento; es una habilidad. En tu mano está desarrollarla. (Codecademy)',
                'No digas: “Es imposible”. Di: “No lo he hecho todavía”. (Proverbio japonés)',
                'La experiencia demuestra que el éxito de un curso de programación depende críticamente de la elección de los ejemplos que se utilice. (Niklaus Wirth)',
                'Al ordenador le importa tres leches tu problema, así que el esfuerzo por que éste realice un proceso por el cual se resuelve dicho problema lo tienes que hacer TÚ. Y el esfuerzo consiste en dárselo mascado para que lo lleve a cabo una y otra vez. (Alex Tolón)',
                'Las raíces del estudio son amargas. Los frutos, dulces. (Cicerón)',
                'Los malos programadores se preocupan del código. Los buenos se preocupan de las estructuras de datos y de sus relaciones. (Linus Torvalds)',
                'La práctica te perfecciona. Descubre cuánta práctica necesitas tú. (Alex Tolón)',
                'Un problema se transforma en desafío cuando le pones fecha de solución. (Anónimo)',
                'Si lo intentas, fallas. No importa. Inténtalo de nuevo. Falla de nuevo. Falla mejor. (Samuel Beckett)',
                'El futuro no es lo que va a pasar sino lo que   vamos a hacer. (Anónimo)']
        update.message.reply_text(random.choice(cita))


def funods(update, context):
    if not salir:
        ods = [
            'Erradicar la pobreza en todas sus formas sigue siendo uno de los principales desafíos que enfrenta la humanidad. Si bien la cantidad de'
            'personas que viven en la extrema pobreza disminuyó en más de la mitad entre 1990 y 2015, aún demasiadas luchan por satisfacer las necesidades'
            'más básicas', 'Al mismo tiempo, es necesario llevar a cabo un cambio profundo en el sistema agroalimentario mundial si queremos alimentar a '
            'más de 820 millones de personas que padecen hambre y a los 2000 millones de personas más que vivirán en el mundo en 2050.',
            'A través de una financiación más eficiente de los sistemas sanitarios, un mayor saneamiento e higiene, y un mayor acceso al personal médico,'
            'se podrán conseguir avances significativos a la hora de ayudar a salvar las vidas de millones de personas.',
            'La educación permite la movilidad socioeconómica ascendente y es clave para salir de la pobreza. Durante la última década, '
            'se consiguieron grandes avances a la hora de ampliar el acceso a la educación y las tasas de matriculación en las escuelas en todos los niveles, '
            'especialmente para las niñas. No obstante, alrededor de 260 millones de niños aún estaban fuera de la escuela en 2018; '
            'cerca de una quinta parte de la población mundial de ese grupo de edad. Además, más de la mitad de todos los niños '
            'y adolescentes de todo el mundo no están alcanzando los estándares mínimos de competencia en lectura y matemáticas.', 'A pesar de estos logros, '
            'todavía existen muchas dificultades: las leyes y las normas sociales discriminatorias continúan siendo generalizadas,'
            ' las mujeres siguen estando infrarrepresentadas a todos los niveles de liderazgo político, y 1 de cada 5 mujeres y '
            'niñas de entre 15 y 49 años afirma haber sufrido violencia sexual o física a manos de una pareja íntima en un período de 12 meses.',
            'En todo el mundo, una de cada tres personas no tiene acceso a agua potable salubre,dos de cada cinco personas no disponen de una instalación básica '
            'destinada a lavarse las manos con agua y jabón,y más de 673 millones de personas aún defecan al aire libre.',
            'A pesar de ello, es necesario prestar una mayor atención a las mejoras para el acceso a combustibles de cocina limpios y seguros, '
            'y a tecnologías para 3000 millones de personas,para expandir el uso de la energía renovable más allá del sector '
            'eléctrico e incrementar la electrificación en el África subsahariana.',
            'A día de hoy, las perturbaciones económicas y financieras derivadas de la COVID-19 (como las alteraciones en la producción industrial, '
            'la caída de los precios de los productos básicos, la volatilidad del mercado financiero y el aumento de la inseguridad) '
            'están desbaratando el ya de por sí tibio crecimiento económico y empeorando los riesgos acentuados de otros factores',
            'La industrialización inclusiva y sostenible, junto con la innovación y la infraestructura,pueden dar rienda suelta '
            'a las fuerzas económicas dinámicas y competitivas que generan el empleo y los ingresos.',
            'A pesar de la existencia de algunos indicios positivos hacia la reducción de la desigualdad en algunas dimensiones, '
            'como la reducción de la desigualdad de ingresos en algunos países y el estatus comercial preferente que beneficia a los países de bajos ingresos, '
            'la desigualdad aún continúa',
            'La rápida urbanización está dando como resultado un número creciente de habitantes en barrios pobres, infraestructuras y servicios inadecuados y sobrecargados '
            '(como la recogida de residuos y los sistemas de agua y saneamiento, carreteras y transporte), lo cual está empeorando la contaminación del aire y el crecimiento urbano incontrolado.',
            'El consumo y la producción mundiales (fuerzas impulsoras de la economía mundial) dependen del uso del medio ambiente natural y de los recursos de una manera que continúa teniendo '
            'efectos destructivos sobre el planeta.',
            'A pesar de que se estima que las emisiones de gases de efecto invernadero caigan alrededor de un 6 % en 2020 debido a las restricciones de movimiento y '
            'las recesiones económicas derivadas de la pandemia de la COVID-19, esta mejora es solo temporal.',
            'No obstante, en la actualidad, existe un deterioro continuo de las aguas costeras debido a la contaminación y a la acidificación de los océanos que está'
            ' teniendo un efecto adverso sobre el funcionamiento de los ecosistemas y la biodiversidad.',
            'En Trabajar con el medio ambiente para proteger a las personas, el PNUMA detalla cómo «reconstruir mejor», mediante una base científica más sólida, políticas que contribuyan a '
            'un planeta más sano y más inversiones verdes.',
            'Por otro lado, los nacimientos de alrededor de uno de cada cuatro niños en todo el mundo con menos de 5 años nunca se registran de manera oficial, lo que les priva de una prueba '
            'de identidad legal, que es crucial para la protección de sus derechos y para el acceso a la justicia y a los servicios sociales.',
            'Para que un programa de desarrollo se cumpla satisfactoriamente, es necesario establecer asociaciones inclusivas (a nivel mundial, regional, nacional y local) sobre principios y valores,'
            'así como sobre una visión y unos objetivos compartidos que se centren primero en las personas y el planeta.']

        update.message.reply_text(random.choice(ods))


def main():
    token = "2106107047:AAF3G3rnt1OGxdUnPCiPh69nOwvRb-bK6Rg"
    updater = Updater(token, use_context=True)
    dispatcher = updater.dispatcher

    global salir
    salir = True
    dispatcher.add_handler(CommandHandler("inicio", start))

    dispatcher.add_handler(CommandHandler("help", help))
    dispatcher.add_handler(CommandHandler("cita", funcita))
    dispatcher.add_handler(CommandHandler("ods", funods))
    dispatcher.add_handler(CommandHandler("final", final))

    dispatcher.add_error_handler(error)
    updater.start_polling()
    updater.idle()


if __name__ == '__main__':
    main()
