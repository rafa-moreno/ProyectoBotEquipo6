"""
Aplicación Botarate.
Desarrollo de un bot que responde de manera automática según lo que
el usuario le diga. Tendrá diferentes niveles de funcionalidad,
desde respuestas simples, respuestas basadas en patrones regulares,
hasta respuestas almacenadas en fichero externo. También se podrá pedir
un PDF con las entradas y salidas de esta ultima opción

Autores:
-Rafael Ruiz Moreno
-Silvia Barea Gómez
-Pablo Lupión Márquez
-Manuel Castellano
"""
import datetime
import pickle
import random
import re

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

# Lista de respuestas que el bot propocionará al usuario en caso de recibir un saludo simple
respuestasSaludo = [">Hola, encantado de conocerte", ">¡Buenas!", ">¿Me estás hablando a mi?",
                    ">¡Hey! ¿Cómo te llamas?"]
respuestasComida = ["¡Me encanta la pizza!", "¡Me encantan las hamburguesas!", "Mi comida favorita es la fabada",
                    "Las patatas fritas me encantan", "Arroz con pollo para los músculos"]


# Función que devuelve el día actual, traducido a español
def obtenerdia():
    diaIngles = datetime.datetime.today().strftime('%A')
    if diaIngles == "Monday":
        return "Lunes"
    elif diaIngles == "Tuesday":
        return "Martes"
    elif diaIngles == "Wednesday":
        return "Miércoles"
    elif diaIngles == "Thursday":
        return "Jueves"
    elif diaIngles == "Friday":
        return "Viernes"
    elif diaIngles == "Saturday":
        return "Sábado"
    else:
        return "Domingo"


# Primera opción del programa, en la que el bot responderá de forma simple a preguntas pre-establecidas
def botsimple():
    # Diccionario que contendrá las diferentes preguntas y respuestas a las mismas.
    dicrespuestas = {"Hola": "Muy buenas, usuario. Soy Botarate",
                     "¿Qué sabes de música?": "Pues la verdad que de eso sé poco",
                     "¿Qué sabes de informática?": "Se mucho sobre eso, ¡Soy un robot!",
                     "Hola, soy Manuel": "Muy buenas, Manuel. Yo soy Botarate",
                     "Hola, soy Rafa": "Hola, Rafa, encantado de conocerte. Yo soy Botarate",
                     "Hola, soy Silvia": "Encantado Silvia, yo soy Botarate",
                     "Hola, soy Pablo": "Buenas, Pablo, yo soy Botarate",
                     "Hola, soy Alex": "Encantado Alex, yo soy Botarate",
                     "¿Cómo está el tiempo hoy?": "Seguramente llueva, o no",
                     "¿Cuál es tu comida favorita?": "Si pudiera comer, sólo comería pizzas pepperoni",
                     "¿Cuántos años tienes?": "¡Qué maleducado!",
                     "¿Qué día es hoy?": "¡Hoy es un gran día!",

                     "Alt": "Lo siento, no te he entendido"}
    entrada = ""
    print("\t\tBot a la escucha...(pregunta cuando quieras)\n")
    # Mientras la entrada no sea "salir" o "Salir", el bot funcionará
    while entrada.casefold() != "salir".casefold():
        entrada = input("\t\t>")
        # Si la entrada se encuentra en el diccionario, se imprimirá la respuesta que tiene asignada
        if entrada in dicrespuestas:
            print(f"\t\t>{dicrespuestas.get(entrada)}")
        # Si la entrada es salir o Salir, imprimirá un mensaje de despedida
        elif entrada.casefold() == "salir":
            print("\t\t>¡Hasta la próxima!\n")
        # En caso de que la entrada no esté en el diccionario, el bot imprimirá un mensaje alternativo
        else:
            print("\t\t>" + dicrespuestas.get("Alt"))


# Función que devuelve todas las palabras de la "fcadena" que no pertenecen a "fpatron"
def obtenercadena(fpatron, fcadena):
    # Lista de palabras (agrupadas en una tupla) de la cadena que coinciden con el patrón
    listaPalabras = re.findall(fpatron, fcadena)
    # Se eliminan de la cadena todas las palabras de esta tupla, quedando sólo lo que no está en el patrón
    for palabra in listaPalabras[0]:
        fcadena = fcadena.replace(palabra, "")
    return fcadena


# Función auxiliar del bot REGEX, en la que se buscan patrones regulares en la entrada
def comprobarentrada(cadena):
    # Patrón que corresponde a un saludo con nombre
    if re.search(patronSaludoNombre, cadena):
        nombre = obtenercadena(patronSaludoNombre, cadena)
        print(f"\t\t>Muy buenas, {nombre}. Soy Botarate")

    # Patrón que corresponde a un saludo simple
    elif re.search(patronSaludoSimple, cadena):
        # Se imprime una respuesta aleatoria correspondiente a un saludo simple
        print(f"\t\t{respuestasSaludo[random.randint(0, len(respuestasSaludo) - 1)]}")

    # Patrón que corresponde a una presentación simple
    elif re.search(patronNombre, cadena):
        nombre = obtenercadena(patronNombre, cadena)
        print(f"\t\t>Encantado de conocerte, {nombre}. ")

    # Patrón que coresponde a una pregunta sobre si sabe algo de alguna materia
    elif re.search(patronPregunta, cadena):
        materia = obtenercadena(patronPregunta, cadena).replace("?", "")
        print(f"\t\t>De {materia} se poco la verdad")

    elif re.search(patronQueDiaEsHoy, cadena):
        print(f"\t\t>Hoy es {obtenerdia()}")

    # Patrón que corresponde a pregunta sobre comida favorita
    elif re.search(patronComidaFavorita, cadena):
        # Se imprime una respuesta aleatoria correspondiente a las comidas
        print(f"\t\t{respuestasComida[random.randint(0, len(respuestasSaludo) - 1)]}")

    # Si la cadena introducida es "salir" o "Salir", finaliza el bot
    elif cadena.casefold() == "salir":
        return
    # Si la cadena no coincide con ningún patrón, el bot responderá un mensaje prederterminado
    else:
        print("\t\t>Lo siento, no te he entendido")


# Segunda opción del programa, en la que el bot responderá analizando la pregunta buscando patrones regulares
def botsimpleregex():
    entrada = ""
    print("\t\tBot a la escucha...(pregunta cuando quieras)\n")
    # Mientras la entrada no sea "salir" o "Salir", el bot funcionará
    while entrada.casefold() != "salir".casefold():
        entrada = input("\t\t>")
        comprobarentrada(entrada)

    print("\t\t>¡Hasta la próxima!\n")


# Función que compara la cadena pasada como parámetro con cada patrón que se encuentre en el fichero
# y devuelve la respuesta asociada a dicho patrón
def comprobarentradafichero(cadenafichero):
    fichero = open("preguntasrespuestas", "rb")
    # Se carga la lista del fichero, la cual contiene una lista de patrones y una lista de respuestas
    listaPatronRespuesta = pickle.load(fichero)
    # La primera posición de la lista será una lista de patrones
    patrones = listaPatronRespuesta[0]
    # La segunda posición de la lista será una lista de respuestas asociadas a los patrones
    respuestas = listaPatronRespuesta[1]
    # Con este contador controlaremos la respuesta que debemos dar a un determinado patrón
    cont = 0
    respuesta = ""
    encontrada = False
    for patron in patrones:
        # Por cada patrón se compara el mismo con la cadena pasada como parámetro a la función
        if re.search(patron, cadenafichero):
            # Si coincide con alguno de ellos, se imprimirá la respuesta correspondiente
            if patron == patronSaludoSimple:
                respuesta = f"{respuestas[cont][random.randint(0, len(respuestasSaludo) - 1)]}"
                print(f"\t\t{respuesta}")

            elif patron == patronComidaFavorita:
                respuesta = f"{respuestas[cont][random.randint(0, len(respuestasComida) - 1)]}"
                print(f"\t\t{respuesta}")

            elif patron == patronQueDiaEsHoy:
                respuesta = str(respuestas[cont]).replace("xx", obtenerdia())
                print(f"\t\t{respuesta}")

            else:
                respuesta = (str(respuestas[cont]).replace("xx", obtenercadena(patron, cadenafichero).replace("?", "")))
                print(f"\t\t{respuesta}")
            encontrada = True
            break
        cont += 1

    fichero.close()
    # Si no se ha encontrado la comparación correcta, se imprimirá el mensaje que corresponda
    if not encontrada and cadenafichero != "salir".casefold():
        respuesta = ">Lo siento no te he entendido"
        print(f"\t\t{respuesta}")

    # Se guardará toda la conversación en un fichero
    conversacionBot = open("conversacion.txt", "a")
    cadenafichero = f"\n>{cadenafichero}"
    respuesta = "\n" + respuesta
    conversacionBot.writelines(cadenafichero)
    conversacionBot.writelines(respuesta)
    conversacionBot.close()


# Función que guarda en un fichero una lista con dos listas, una correspondiente a patrones regulares
# y otra, con las respuestas asociadas a los mismos, en las mismas posiciones
def botfichero():
    # Se crea o se borra el contenido del fichero de la conversación
    conversacion = open("conversacion.txt", "w")
    conversacion.close()
    fichero = open("preguntasrespuestas", 'wb')
    listaPatronesRespuestas = [[patronSaludoNombre, patronNombre, patronSaludoSimple, patronPregunta,
                                patronQueDiaEsHoy, patronComidaFavorita],
                               [">Muy buenas, xx. Soy Botarate", ">Encantado de conocerte, xx.",
                                respuestasSaludo, ">De xx se poco la verdad", ">Hoy es xx", respuestasComida]]
    pickle.dump(listaPatronesRespuestas, fichero)
    fichero.close()

    entrada = ""
    print("\t\tBot a la escucha...(pregunta cuando quieras)\n")
    # Mientras la entrada no sea "salir" o "Salir", el bot funcionará
    while entrada.casefold() != "salir".casefold():
        entrada = input("\t\t>")
        comprobarentradafichero(entrada)

    print("\t\t>¡Hasta la próxima!\n")
    c = open("conversacion.txt", "a")
    c.writelines(">¡Hasta la próxima!")


# Función que crea un PDF con un infome de la conversación tenida con el Bot durante la Opción 3
def informeconversacion():
    caracteres = 0  # Variable que almacenará el número de caracteres totales de la conversación
    palabras = 0  # Variable que almacenará el número de palabras totales de la conversación
    palabraDe = 0  # Variable que almacenará el número de veces que aparece la palabra "de"
    hoy = datetime.datetime.today().date()  # Fecha del día actual

    # Se crea el PDF y se imprime la imagen correspondiente, así como el título del mismo
    doc = canvas.Canvas("informe.pdf", pagesize=A4)
    doc.drawImage("chatbot_python.jpg", 120, 600, width=350, height=175)
    doc.setFont("Helvetica-Bold", 21)
    doc.drawString(123, 560, "INFORME DE LA CONVERSACIÓN")
    doc.setFont("Helvetica", 12)

    # Se guarda la conversación desde el fichero en forma de lista de cadenas
    conversacionInf = open("conversacion.txt", "r")
    listaCadenas = conversacionInf.readlines()
    conversacionInf.close()
    posY = 530  # Variable que controlará la posición Y en la que se imprime la línea
    nPag = 1  # Número de página actual
    doc.setFont("Helvetica", 12)
    doc.drawString(500, 40, "Page #1")

    # Se imprimirá cada cadena de la lista de cadenas de la conversación
    for cadena in listaCadenas:
        cadena = cadena.replace("\n", "").replace("\t", "")  # Se eliminan caracteres especiales
        doc.drawString(80, posY, cadena)
        # La posición Y disminuye por cada línea
        posY -= 15
        # Si esta posición llega al pie de página, se aumentará el número de página y se ubicará la Y arriba del todo
        if posY == 50:
            nPag += 1
            doc.showPage()  # Nueva página
            doc.drawString(500, 40, f"Page #{nPag}")  # Nuevo indicador del número de página escrito abajo a la derecha
            posY = 755  # Posición Y arriba de la página

        # A continuación se realiza el conteo de número de palabras, caracteres y número de palabras "de" que hay
        listaPalabra = cadena.split()
        palabras += len(listaPalabra)
        for palabra in listaPalabra:
            palabra = palabra.replace(">", "")
            if palabra == "de":
                palabraDe += 1
            for i in palabra:
                caracteres += 1

    # Para el siguiente texto, se controlará que no se imprima demasiado debajo de la página, llegando a cortarse
    if posY < 150:
        # Por ello, si la posición es menor de 150, se incrementará la página y se situará la Y arriba del todo
        nPag += 1
        doc.showPage()
        doc.drawString(500, 40, f"Page #{nPag}")
        posY = 805

    doc.setFont("Helvetica", 14)
    # Se imprimen las líneas que corresponden
    doc.drawString(80, posY - 50, f"La conversación es del {hoy}")
    doc.drawString(80, posY - 75, f"Consta de {caracteres} caracteres")
    doc.drawString(80, posY - 100, f"Está compuesta por {palabras} palabras")
    doc.drawString(80, posY - 125, f"La palabra de aparece {palabraDe} veces")
    doc.save()


# Programa principal
patronSaludoNombre = re.compile(r"^(Hola|Buenas)(,?)( *soy )|( *me llamo )|( *mi nombre es )", re.IGNORECASE)
patronSaludoSimple = re.compile(r"^(Hola|Buenas)([A-Za-z ])*", re.IGNORECASE)
patronNombre = re.compile(r"^(Soy )|(Me llamo )|(Mi nombre es )", re.IGNORECASE)
patronPregunta = re.compile(r"([¿]?Qu[é|e] sabes de )\w+|(^[¿]*sabes algo de )\w+", re.IGNORECASE)
patronQueDiaEsHoy = re.compile(r"[¿]?Qu[é|e] d[i|í]a es hoy[?]?\w*", re.IGNORECASE)
patronComidaFavorita = re.compile(r"comida favorita[?]?\w*", re.IGNORECASE)

salir = False

while not salir:

    # Menú principal del programa con las 5 opciones posibles
    print("\n\t\t\tAPLICACIÓN BOT-ARATE\n")
    print("\t\t1) Bot simple (respuestas planas...)")
    print("\t\t2) Bot simple (respuestas REGEX)")
    print("\t\t3) Bot simple mejorado desde fichero")
    print("\t\t4) Informe de la conversación (PDF)")
    print("\t\t5) Salir")

    # Opción que el usuario elegirá
    opcion = input("\n\t\tOpción: ")

    if opcion == "1":
        # Opción 1: Bot simple
        botsimple()
    elif opcion == "2":
        # Opción 2: Bot simple usando REGEX
        botsimpleregex()
    elif opcion == "3":
        # Opción 3: Bot REGEX mejorado desde fichero, guardando la conversación tenida en un archivo de texto
        botfichero()
    elif opcion == "4":
        # Opción 3: Informe PDF de la conversación tenida en la Opción 3
        informeconversacion()
    elif opcion == "5":
        # Opción 5: Salir del programa
        salir = True
    else:
        # Si no introduce una opción válida se imprimirá el mensaje correspondiente
        print("Introduzca una opción válida")
